import React from "react";
import NavbarDemo from "./components/Navbar";


function App() {
  return (
    <div>
      <NavbarDemo />
     
    </div>
  );
}

export default App;